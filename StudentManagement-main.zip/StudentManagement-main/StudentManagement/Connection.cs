﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentManagement
{
    internal class Connection
    {
        public static string connectionString = @"Data Source=NGAIVINH\SQLEXPRESS;Initial Catalog=StudentManage;Integrated Security=True";
    }
}
